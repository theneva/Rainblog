Har lagt inn en bruker med
brukernavn: sindrenm
og
passord: ananas

Bruk søkefunksjonaliteten på forsiden for å utforske annet content, eller bare les dokumentasjonen.

Det skal ikke være nødvendig å kjøre andre kommandoer enn `bundle install`, og `rails s[erver]`. Du skal i utgangspunktet ikke trenge å kjøre `rake db:migrate` fordi jeg leverer sqlite3-fila, men plutselig skjer det noe rart :)