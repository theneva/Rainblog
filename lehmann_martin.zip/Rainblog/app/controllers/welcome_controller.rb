# The "landing" page of the application. Accessed at root.
class WelcomeController < ApplicationController
end
