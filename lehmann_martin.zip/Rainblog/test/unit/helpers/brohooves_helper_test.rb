require 'test_helper'

class BrohoovesHelperTest < ActionView::TestCase
end
