require 'test_helper'

class BrohoofTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
