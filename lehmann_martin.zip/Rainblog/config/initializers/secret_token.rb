# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Rainblog::Application.config.secret_token = 'c480abfed1c7587513a0b7b861ba3e17c99c120b7c33bb8e8c1e39286e12ed592d092f3ab5a565556ff883d02e94a8dc74b5f3c656546f918c9351c16398cd14'
